package mypack;

public class WebSecurityConfigurerAdapter {

}
