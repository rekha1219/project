package mypack;

public class SecurityContextHolder {

	public static Object getContext() {
		// TODO Auto-generated method stub
		return null;
	}

}
