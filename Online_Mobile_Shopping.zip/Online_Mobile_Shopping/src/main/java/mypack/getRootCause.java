package mypack;

public class getRootCause {

}
