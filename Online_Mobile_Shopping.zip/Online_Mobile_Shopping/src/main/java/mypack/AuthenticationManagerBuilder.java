package mypack;

public class AuthenticationManagerBuilder {

}
