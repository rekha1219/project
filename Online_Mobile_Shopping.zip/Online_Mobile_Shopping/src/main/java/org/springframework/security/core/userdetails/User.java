package org.springframework.security.core.userdetails;

public class User {

}
