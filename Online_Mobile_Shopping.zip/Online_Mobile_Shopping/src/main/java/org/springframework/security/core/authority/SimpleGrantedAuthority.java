package org.springframework.security.core.authority;

public class SimpleGrantedAuthority {

}
