package org.springframework.security.core;

public class GrantedAuthority {

}
