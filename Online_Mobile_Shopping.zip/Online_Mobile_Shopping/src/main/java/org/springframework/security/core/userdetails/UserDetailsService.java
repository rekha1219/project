package org.springframework.security.core.userdetails;

public class UserDetailsService {

	public char[] getPassword() {
		
		return null;
	}

	public char[] getUsername() {
		
		return null;
	}

	public char[] isEnabled() {
		
		return null;
	}

	
}
