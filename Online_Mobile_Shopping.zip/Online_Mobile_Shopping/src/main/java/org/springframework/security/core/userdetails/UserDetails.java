package org.springframework.security.core.userdetails;

public class UserDetails {

	public char[] getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	public char[] getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

	public char[] isEnabled() {
		// TODO Auto-generated method stub
		return null;
	}

}
