package org.apache.commons.validator.routines;

public class EmailValidator {

	public static EmailValidator getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isValid(String email) {
		// TODO Auto-generated method stub
		return false;
	}

}
